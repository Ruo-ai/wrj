"""Team 742 red-stage submission: Startup44 Delivery R2."""
from swarm_rescue.simulation.reporting.team_mode import TeamMode
from swarm_rescue.solutions.my_drone_red_startup44_delivery import MyDroneRedStartup44Delivery


def drone_class_for_mode(mode: str):
    if TeamMode.from_string(mode) == TeamMode.PLACE:
        return MyDroneRedStartup44Delivery
    raise ValueError("This submission is for the red PLACE stage only.")
