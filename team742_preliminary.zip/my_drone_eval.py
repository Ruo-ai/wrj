from swarm_rescue.simulation.reporting.team_mode import TeamMode
from swarm_rescue.solutions.red_release4 import MyDroneRed4, MyDroneRescue4

def drone_class_for_mode(mode):
    return MyDroneRed4 if TeamMode.from_string(mode) == TeamMode.PLACE else MyDroneRescue4
