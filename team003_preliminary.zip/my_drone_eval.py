"""Release 6: red placement strategy and original example rescue compatibility."""
from swarm_rescue.simulation.reporting.team_mode import TeamMode
from swarm_rescue.solutions.red_release6 import MyDroneRed6, MyDroneRescue6


def drone_class_for_mode(mode: str):
    return MyDroneRed6 if TeamMode.from_string(mode) == TeamMode.PLACE else MyDroneRescue6
