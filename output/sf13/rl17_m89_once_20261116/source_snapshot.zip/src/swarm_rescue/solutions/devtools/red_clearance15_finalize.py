"""Write RC15 stage report from verified full-run evidence, no evaluation."""
from pathlib import Path
import json
import subprocess
from swarm_rescue.solutions.devtools import red_stopturn_match_report as base
from swarm_rescue.solutions.devtools.red_clearance15_review import NAMES,KINDS
from swarm_rescue.solutions.devtools.red_clearance15_review import panel,marks
from swarm_rescue.solutions.devtools.red_local13_finalize import assets
from swarm_rescue.solutions.devtools import red_consistent12_review as panels
from swarm_rescue.solutions.devtools import red_lines11_review as lines

ROOT=Path.cwd().resolve()
DEV=ROOT/'output/sf13/rc15_dev_20261116'
BATCH=ROOT/'output/sf13/rc15_m89_once_20261116'
OUT=ROOT/'output/sf13/rc15_m89_review_20261116'
REPORT=ROOT/'复赛阶段_FS4_红队RC15_最小净空四局实测_20261116.md'

def main():
    assert not REPORT.exists(),'Existing report is read-only'
    summary=base.read(OUT/'summary.json');rows=summary['rows'];assert len(rows)==4
    # The first close-up had crowded row titles. Preserve it and render a clean
    # second file, without touching native results, receipts or frozen sources.
    panels.NAMES=NAMES
    fig,axes=base.plt.subplots(2,2,figsize=(18,14))
    fig.subplots_adjust(left=.02,right=.98,top=.85,bottom=.08,wspace=.05,hspace=.52)
    for col,c in enumerate(NAMES):
        r=next(r for r in rows if r['map']=='Map08' and r['controller']==c);data=assets(r)
        for y,kind in enumerate(('trajectories','mapping')):
            panel(axes[y,col],kind,r,data)
            if kind=='mapping':marks(axes[y,col])
            axes[y,col].set(xlim=(880,1660),ylim=(1122,690))
    fig.suptitle('Map08 中间入口 G1 / 下方入口 G2 / 最右下入口 G3',fontproperties=lines.FONT,fontsize=22,y=.98)
    fig.text(.5,.94,'上：实际完整轨迹；下：官方建图差异。左RL11，右RC15；G2两版均未穿过。',ha='center',fontproperties=lines.FONT,fontsize=14)
    fig.text(.5,.025,'G1约139px；G2约56px；G3约46px（真值栅格截面，仅离线）。标线不是策略目标。',ha='center',fontproperties=lines.FONT,fontsize=12)
    base.save(fig,OUT/'Map08_gate_focus_v2.png')
    with (OUT/'report_v2.md').open('x',encoding='utf-8') as f:
        f.write((OUT/'report.md').read_text(encoding='utf-8').replace('Map08_gate_focus.png','Map08_gate_focus_v2.png'))
    protected=base.read(DEV/'protected_before.json')
    changed=[n for n,h in protected.items() if not (ROOT/n).is_file() or base.digest(ROOT/n)!=h]
    verification=dict(protected_files=len(protected),changed=changed,
        tracked_diff=subprocess.check_output(['git','diff','--stat'],text=True),
        blue_phases=0,full_red_phases=4,valid=sum(r['red_valid'] for r in rows),
        root_zip_sha256=base.digest(ROOT/'team742_preliminary.zip'),
        callback_errors=[r['callback_errors'] for r in rows],diagnostic_errors=[r['clearance_diagnostic_errors'] for r in rows])
    with (OUT/'verification.json').open('x',encoding='utf-8') as f:json.dump(verification,f,ensure_ascii=False,indent=2)
    regression=any(d['map_score'] < -1 or d['contacts_wall']>0 for d in summary['deltas']) or any(not r['red_valid'] for r in rows)
    verdict='拒绝替换 RL11；保留 RC15 实验记录' if regression else '继续实验；证据不足以替换 RL11'
    doc=['# RC15：RL11 最小净空 / 贴墙窄路实验','',f'2026-11-16。**{verdict}。** 本轮只运行 Map08/09 × RL11/RC15 ×1，共4场完整红阶段、0蓝。正式入口不变。','',
        '## 已核实状态与范围','',
        '接手 HEAD=586ab993ae051c3dc8b922a53828e8ff643f2432，git status 干净。RL11=WallLineMapper + RN7-B（S6运动/A3地图/进阶2导航与布弹）；RL12/13/14均保留。最近RL14完整批基线M为63.1415/73.3676；该批其他三个机制不作为本轮组合。正式place仍为MyDroneRedAdvanced2，rescue仍示例。',
        f'开始时冻结{len(protected)}个既有文件哈希；结束变化={changed}。未修改蓝队、共享定位/通信、物理/评分、入口、旧报告与旧结果；根目录包未动。无提交、推送、打包、分支操作。',
        '运行前可见Get-Process列表未显示其他Python评测；进程可见性受沙箱限制，不能保证整机绝无其他负载。仿真由同一驱动串行，1CPU/4,000,000,000字节，5400步/180秒，外层240秒。完整局期间不运行其他仿真或性能测试，不改冻结源码。新增离线图册工具不参与控制。','',
        '## 实际碰撞体与旧净空链','',
        '实例化原生DroneBase并读取pm_shapes[0].get_vertices()，与RN7常量逐点一致：',
        '```text','(-13,-10), (-11,-12), (5,-12), (12,-11), (12,11), (10,13), (-10,13), (-13,10)','```',
        'DroneBase使用drone_v2.png的hull形状。交互层radius=10不是碰撞半径；原生base.radius及凸包最大范数为16.4012px。相对通道轴0/15/30/45/60/90度时横向投影宽度为25/28.8762/31.7846/32.5269/32.1506/25px。不得把机身缩成10px圆。', '',
        '|层|RL11/RN7现有规则|RC15处理与限制|',
        '|---|---|---|',
        '|远距离目标/粗图|20px栅格，射线自由区退26px；墙>=2，再十字3×3膨胀；4邻域搜索|保留保守远图；近场细图独立提供已观测可达目标，粗拒绝不会否决细任务|',
        '|巡查候选|3×3方形安全膨胀、7×7近墙、粗可达|原远图巡查保留；细任务绕过此筛选，非全图统一2px|',
        '|粗路径检查/跟踪|8px线采样，旧粗膨胀|当前细任务范围165px内用新凸包证书；远处仍保守粗图|',
        '|RN7细图|2px格，扇面退3px，TRACK_RADIUS=18.5，PLAN_RADIUS=19.9142|复用R8当前扫描自由扇面，完整凸包只侵蚀一次；不叠加旧圆|',
        '|RN7/常规速度|细任务圆余量；常规25px圆或22px窄路圆|细任务用同一凸包C空间覆盖最终力指令；非任务时RL11原控制器回退|',
        '|转向|S6停稳转向/RN7零旋转|细任务保持当前机身朝向，合法横移拐弯；不搜索新的最窄姿态。几何函数另验证连续旋转全过程，不能把端点安全当全程安全|',
        '|同机/队友/放弹|语义动态物体、让行、近弹55px不接管|保持；不是把动态机体当墙拟合，也不取消物理碰撞|', '',
        '这些旧阈值属于不同层的独立否决，不能把26+20+25直接当一个物理距离相加。此次为近场旁路实验；没有声称远距离全局图已改成姿态搜索图。远图只有带漂移的20px证据，直接全局降膨胀会把未知/错墙当精确几何，故保留其保守性并明确边界。','',
        '## 新机制、开关与计算边界','',
        '新文件my_drone_red_clearance15.py：MyDroneRedClearance15只开MIN_CLEARANCE_ENABLED；SAFETY_MARGIN=2.0可调2～4px/侧。MyDroneRedClearance15Off关闭后恢复RL11/RN7；本轮不与RL14组合。原LINE_MAPPING、定位更新、部署函数、汇图/硬截止均继承RL11。',
        '当前合法雷达形成440×440px、2px格的身体坐标自由图，不长期并集漂移扫描，不跨缺测扇区填自由。利用已有短墙拟合且先复制雷达数组，避免拟合原地改写传感器输入。完整凸包 + 2px余量 + 1.414px半格对角误差 + 0.5px连续平移采样界只计一次。旋转检查最多3度间隔，另加外接半径×半角步界，并取所有中间姿态核并集；这比实际扫掠更保守。',
        '2px不是绝对安全承诺，也不是2.5px标准差雷达噪声的置信界。合成36px通道可以通过，不代表29px（25+2+2）真实噪声通道可靠可过。固定姿态对斜门可能保守；未实现自动选姿态绕行或全局SE(2)搜索。',
        '细目标、细路径邻接、拉直和跟踪均用同一C空间；选择方向取原导航目标，避免先被旧25/22px避障偏转再作为探索方向。连续任务保留最多240步、每600步最多8次、累计32次/1400活跃步；无进展35步、观测阻挡12步、队友等待7+3×机号步后退出/冷却。近期失败端点180步内不立即重试。',
        '每次细搜索最多6000节点、165px净距离/约247.5px路径；沿已观测段走到下个观察点后继续，最多2次短段延续。身体帧路径每步使用实际里程计距离/方向/转角搬移；失去里程计取消任务。当前扫描更新、实测速率制动与预测停止扫掠仍保留，不能由指令速度假定位置。窄任务不旋转机身，因此横移转弯检查的是完整凸包平移，不是圆心线。',
        '额外净空缩小允许更接近墙面，但没有强制偏心贴墙：追求减少拒绝，同时保留可用余量。主动把机身压到2px边缘会增加噪声碰撞风险，未混入本实验。','',
        '这是贯通局部判据的整体实验，还包括原导航目标方向、可刷新任务预算与细路径证书，不能把RL11→RC15的全部差值归因于“仅把余量改成2”。地图器、定位和布弹代码未变。雷达相邻射线自由扇面是几何近似，噪声或射线间极薄遮挡仍会带来误差；没有全局未知区域清空。','',
        '## 真实运行的测试与限制','',
        '22项行为检查通过（1.78秒；4条Pillow旧接口弃用警告）。检查原生凸包、25/29/36/46px、斜通道、旋转中间碰撞、L形未知角不能切穿、已知死路、含噪制动、里程计转角/侧滑、动态机等待、无进展、健康/放弹/截止让权、继承关系和关开关。合成角落/动态机检查不是原生五机门口交会验收。',
        'Map08三组128步冒烟（RL11/RC15/Off）无崩溃/诊断异常，Off与基线完整记录合法输入精确相同；冒烟均明确不是完整有效比赛。',
        '原生小场景首轮夹具Coarse缺少obstacle/free字段，4场异常、1场完成，全部保留在rc15_native_20261116。只修新夹具后另建rc15_native_fixed_20261116，不覆盖失败；候选源码未因此修改。','',
        '|小场景|是否真穿过|接触|步数|场景秒|结果解释|','|---|---|---:|---:|---:|---|']
    native=base.read(ROOT/'output/sf13/rc15_native_fixed_20261116/results.json')
    for r in native:
        note='绕到通道外，不算穿过' if r.get('bypassed') else ('已通过' if r.get('passed') else '未通过；保留失败/退出记录')
        doc.append(f"|{r['case']}|{r['passed']}|{r['contacts']}|{r['steps']}|{r['seconds']:.3f}|{note}|")
    doc+=['','36px无噪声通过，而真实噪声36px未进入；46px含噪通过；25px没有穿过；死路停止且无墙接触。这是最小余量的实际限制，不能只报理想成功。','',
        '## 四局完整红阶段','',
        'Map08 seed=200806601，1660×1122，NO_GPS；Map09 seed=2477227837，1700×1100，NO_GPS+NO_COM。5红机×2弹，每组只有attempt_001。同种子不等于相同观测或轨迹，地图器未改但轨迹变化会改变所有建图输入。蓝队难度、完整官方原始/有效总分均未评测。','',
        '|地图/版本|红有效|地图M|墙体W|时间T|步数|墙钟秒|弹数|平均健康|墙/机接触|真墙命中|受罚误画|',
        '|---|---|---:|---:|---:|---:|---:|---:|---:|---|---:|---:|']
    for r in rows:doc.append(f"|{r['map']}/{NAMES[r['controller']]}|{r['red_valid']}|{r['map_score']:.4f}|{r['wall_score']:.4f}|{r['time_score']:.4f}|{r['red_steps']}|{r['red_walltime']:.3f}|{r['placed_count']}|{r['health']}|{r['contacts_wall']}/{r['contacts_drone']}|{r['wall_hits']}|{r['charged_pixels']}|")
    doc+=['','|地图|ΔM|ΔW|Δ时间秒|Δ墙接触|Δ机接触|Δ观察自由像素|','|---|---:|---:|---:|---:|---:|---:|']
    for d in summary['deltas']:doc.append(f"|{d['map']}|{d['map_score']:+.4f}|{d['wall_score']:+.4f}|{d['red_walltime']:+.3f}|{d['contacts_wall']:+}|{d['contacts_drone']:+}|{d['sampled_visible_free_pixels']:+}|")
    doc+=['','Map08 RC15在3989步明确触发原有early_finish_ready，提交机记录库存全空且各来源版本满足原条件；原版4536步。少547步不是超时，也不是改了提交策略，但不能把较少总秒数当计算效率改善。RC15该图54次细目标选择，其中42次原粗线判据拒绝；细任务实际生效，却不等于新增任务有高观察价值。']
    doc+=['','耗时是引擎墙钟而不是CPU秒；限制为单CPU，实际峰值Job内存和诊断开销逐局保留在summary/resources。可见区为每8步、4px采样并插值，不是精确完整传感器覆盖。','',
        '## 入口、成图与送达证据','',
        'G1为Map08中间入口（真值栅格约139px）；G2为下方56px入口；G3为最右下46px入口。这些坐标只存在离线工具，策略文件无地图名/目标真值坐标。中心越线与完整侧向通过定义见图册。','',
        '|版本/入口|附近机帧|中心越线|完整侧向通过|附近细目标选择事件|','|---|---:|---:|---:|---:|']
    for r in rows:
        for k,g in r.get('gates',{}).items():doc.append(f"|{NAMES[r['controller']]}/{k}|{g['near_drone_frames']}|{len(g['center_crossings'])}|{g['complete_side_changes']}|{len(r['gate_tasks'][k])}|")
    doc+=['','|地图/版本|观察自由区估计%|重复探索采样|实际墙面端点|本机终图含这些端点|提交含这些端点|本机有但提交无|最旧来源延迟步|','|---|---:|---:|---:|---:|---:|---:|---:|']
    for r in rows:
        q=r['dense_chain'];age=max((s['age'] for s in r['source_snapshots'] if s['age'] is not None),default=None)
        doc.append(f"|{r['map']}/{NAMES[r['controller']]}|{r['sampled_visible_free_fraction']*100:.2f}|{r['repeated_exploration_samples']}|{q['observed_true_surface']}|{q['observed_and_own_final']}|{q['observed_and_submitted']}|{q['own_observed_missing_submission']}|{age}|")
    doc+=['','**Map08已证实：**G2和G3两版均无中心越线；G1完整侧向通过17→5，G2附近机帧81→54，下方通道实际进入机帧均为0。下方通道采样可见自由像素17656→2160；该区域实际观测墙面端点1208→1122，其中本机终图有1130→570、提交命中1155→580。不能说纯粹没看到，也不能说进入了但仅仅没送达。',
        'RC15在G1附近记录3个估计细目标、G2/G3附近0个；目标按导航估计坐标归类，不能排除定位误差使其落错框。RL11没有该细目标日志，“0个新式事件”不代表没有原导航任务。拒绝原因全局统计不足以证明G2每次均被哪个判据拒绝；因此目前不把它判成已证实的单一窄口几何问题。',
        '**Map09已证实：**RC15提交收到来源2的版本420，提交时落后3807步；10385个逐步观测且本机终图仍有的真墙端点像素未进入提交图，RL11为0。全机终图离线并集地图公式值为43.8569，仍低于RL11的73.3853；这仅是忽略通信的离线诊断值，不是官方成绩、可实现分数或理论上限。因此送达损失存在，同时探索/本机成图也退步。',
        'Map09 RC15在4228步、151.27秒提交，与原有0.84×180秒墙钟提交保护一致；没有early_finish_ready日志。仍属正常完成而非引擎180秒超时，但运行到的仿真步数减少。Job峰值722.6～733.5MB；被动窄路诊断每局约1.19～1.33秒。没有把墙钟当CPU时间。']
    doc+=['','送达表来自提交机实际接受的来源版本；不把发送当收到。观察墙端点、本机最终像素与提交像素是不同统计，只有交集证据能说本机有而提交缺少。未进门也可能雷达观察门内局部墙，不能把中心轨迹当雷达覆盖。',
        'RC15记录每次进入/重规划/释放的目标、估计位姿、路径、实测速率、余量和原因，16步采样原粗路线/健康/实际位姿；拒绝细探测记录分类计数，未保存每次被拒绝探测的完整候选集，故不能精准还原所有“发现但未选”的时刻。没有在线显式门对象/门宽估计，净空由完整配置空间直接判定；不能虚构逐门宽测量。',
        '已证实事实是各局分数、实际穿越、原始接触、观测像素和来源版本；原粗图阈值可能阻断某些入口由源码支持，但不是全部徘徊的已证实唯一原因。定位漂移、目标吸引、让行和扫描波动仍可能影响结果。完整链路因果需要进一步同合法输入的局部规划重放，不用单张轨迹图猜。','',
        '## 本轮对照图','']
    for kind,label in KINDS.items():doc += [f'![{label}]({(OUT/f"comparison_{kind}.png").as_posix()})','']
    doc += [f'![Map08入口放大]({(OUT/"Map08_gate_focus_v2.png").as_posix()})','',
        f'[四局完整图册：逐局真值/探测/提交/误画、各机轨迹、炸弹与墙体]({(OUT/"report_v2.md").as_posix()})','',
        '## 命令与新增文件','',
        '行为测试：','```powershell',"Set-Location -LiteralPath 'E:\\桌面\\gitee\\swarm-eod'",'.\\.venv\\Scripts\\python.exe -B -m pytest src/swarm_rescue/solutions/devtools/test_red_clearance15.py -q -p no:cacheprovider','```','',
        '逐局完整红回放：']
    for r in rows:doc+=['',f"{r['map']} / {NAMES[r['controller']]} / r1 / seed {r['red_seed']}",'```powershell',f".\\replay_map.cmd '{r['attempt']}'",'```']
    doc+=['','蓝阶段未运行，没有本轮蓝回放。','',
        '如用户决定独立复测，下列只准备同配置4红/0蓝，不自动开始；确认资源空闲后才执行第二行：','```powershell',
        '$rc15Out = "output/sf13/rc15_user_$(Get-Date -Format yyyyMMdd_HHmmss)"',
        '.\\.venv\\Scripts\\python.exe -B -m swarm_rescue.solutions.devtools.red_clearance15_batch --output $rc15Out --maps Map08 Map09 --controllers rl11_lines rc15_clearance --rounds 1',
        '.\\.venv\\Scripts\\python.exe -B -m swarm_rescue.solutions.devtools.red_clearance15_batch --output $rc15Out --maps Map08 Map09 --controllers rl11_lines rc15_clearance --rounds 1 --run',
        '.\\.venv\\Scripts\\python.exe -B -m swarm_rescue.solutions.devtools.red_clearance15_review --batch $rc15Out --output "${rc15Out}_review"','```','',
        '新增Python（全部solutions内）：my_drone_red_clearance15.py；devtools/test_red_clearance15.py、red_clearance15_native.py、red_clearance15_diagnostics.py、red_clearance15_batch.py、red_clearance15_review.py、red_clearance15_finalize.py。原有代码只导入复用；不引入外部算法代码或新依赖。',
        '输出：rc15_dev_20261116、rc15_smoke_20261116、rc15_native_20261116（保留失败）、rc15_native_fixed_20261116、rc15_m89_once_20261116、rc15_m89_review_20261116。原始源码快照、receipt/result/log/录像/合法输入全保留。', '',
        '## 结论与下一步','',f'**{verdict}。** 每图只有一轮，不能证明普遍优势。小净空能改变几何可达性，但噪声场景入口失败仍存在；实际通过、地图分、墙体分、健康及送达必须一起判断。',
        '下一步优先基于本轮门口采样与完整合法雷达记录，检查真实入口附近是哪一级拒绝及拒绝时墙段/侧滑状况；把几何误拒与目标未选分开。若探索增加却M或W回退，不默认叠加送达或新建图来掩盖本因素的代价。本阶段结束，等待用户查看/继续，不自动扩图、搜索或重跑挑分。']
    REPORT.write_text('\n'.join(doc)+'\n',encoding='utf-8')
    print(json.dumps(dict(report=str(REPORT),verification=verification,verdict=verdict),ensure_ascii=False,indent=2))

if __name__=='__main__':main()
